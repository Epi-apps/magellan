# sample-c
C Devcontainer Sample

### Running the project

Open the terminal and run:
```sh
gcc main.c -o HelloWorld
./HelloWorld
```
Or
```sh
cmake .
make
./HelloWorld
```
Or just press the *Run Code* button found in the top right of the editor panel.
### Want to contribute?

Feel free to open a PR with any suggestions for this test project 😃 
